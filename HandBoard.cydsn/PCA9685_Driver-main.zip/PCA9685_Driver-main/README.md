# PCA9685_Driver

Driver for sending pwm signals using the PCA9685

Name I2C block in Top Design "I2C"

Example code of using the driver can be found in main.c
